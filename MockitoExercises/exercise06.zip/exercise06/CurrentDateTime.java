package exercise06;

/**
 * 
 */
public class CurrentDateTime {

    public CurrentTime getCurrentTime() {
        return new CurrentTime();
    }
}
