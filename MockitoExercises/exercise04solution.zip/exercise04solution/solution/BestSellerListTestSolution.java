package exercise04.solution;

import exercise04.BestSellerDatabase;
import exercise04.BestSellerList;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import shared.Book;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Exercise 04 - Verify method calls
 *
 * 
 */
@RunWith(MockitoJUnitRunner.class)
public class BestSellerListTestSolution {

    @Mock
    private BestSellerDatabase database;

    @Test
    public void testAddBookIfBestSeller() throws Exception {
        final BestSellerList bestSellerList = new BestSellerList(database);

        final Book potterBook = new Book(1, "Harry Potter");
        final Book yellowBook = new Book(2, "50 Shades of Yellow");

        bestSellerList.addBookIfBestSeller(potterBook, 200000);
        bestSellerList.addBookIfBestSeller(yellowBook, 70000);

        verify(database, times(1)).add(potterBook);
        verify(database, times(0)).add(yellowBook);
    }

}