
public class Main {
	public static void main(String[] args) {
		Database db1,db2,db3;

		// refers to the only object of Database
		db1 = Database.getInstance();
		db2 = Database.getInstance();
		db3 = Database.getInstance();
		
		db1.getConnection();
		db2.getConnection();
		db3.getConnection();

	}
}
