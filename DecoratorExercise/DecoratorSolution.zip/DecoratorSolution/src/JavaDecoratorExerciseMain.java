
public class JavaDecoratorExerciseMain {
	public static void main(String[] args) {
		 
	      Car car1 = new BMW();
	      Car car2 = new Chevrolet();
	 
	      Car paintCar1 = new PaintCar(car1);
	      paintCar1.build();
	       
	      Car paintCar2 = new PaintCar(car2);
	      paintCar2.build();
	       
	   }
	 
}
