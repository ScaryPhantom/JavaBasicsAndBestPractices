public class BMW implements Car{
      
    public void build(){
        System.out.println("A BMW car have been built.");
    }
         
}