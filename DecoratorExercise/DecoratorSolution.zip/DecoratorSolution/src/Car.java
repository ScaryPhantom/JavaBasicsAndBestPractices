 
public interface Car {
     
    // This method build a car.
    public void build();
}