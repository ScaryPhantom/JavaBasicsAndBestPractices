public class Chevrolet implements Car{
  
    public void build(){
        System.out.println("A Chevrolet car have been built.");
    }
     
}