public interface Command {
	public abstract void execute();
}