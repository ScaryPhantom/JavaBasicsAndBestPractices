public class UniversalRemote {

	public static HomeElectronics getActiveDevice() {
// here we will have a complex electronic circuit :-)
// that will maintain current device
		LightSystemReceiver ls = new LightSystemReceiver();
		return ls;
	}
}