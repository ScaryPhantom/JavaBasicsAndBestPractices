
public interface Strategy {
	
	public float calculation(float a, float b);

}
