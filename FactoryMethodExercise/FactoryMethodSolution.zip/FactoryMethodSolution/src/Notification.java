
public interface Notification {
		void notifyUser();
}
//This interface could be created as an abstract class as well
