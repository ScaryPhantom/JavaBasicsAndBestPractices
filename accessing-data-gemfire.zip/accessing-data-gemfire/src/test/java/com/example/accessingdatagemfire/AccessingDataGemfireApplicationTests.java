package com.example.accessingdatagemfire;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccessingDataGemfireApplicationTests {

	@Test
	void contextLoads() {
	}

}
