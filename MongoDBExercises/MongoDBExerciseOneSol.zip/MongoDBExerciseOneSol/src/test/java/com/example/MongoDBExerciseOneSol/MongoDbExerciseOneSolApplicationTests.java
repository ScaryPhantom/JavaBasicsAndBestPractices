package com.example.MongoDBExerciseOneSol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoDbExerciseOneSolApplicationTests {

	@Test
	void contextLoads() {
	}

}
