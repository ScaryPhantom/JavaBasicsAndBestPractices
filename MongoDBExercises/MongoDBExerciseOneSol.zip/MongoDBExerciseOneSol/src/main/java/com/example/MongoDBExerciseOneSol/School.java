package com.example.MongoDBExerciseOneSol;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;

@Getter
@Document
public class School {

    @Id
    private String id;
    private String name;
    private int establishmentYear;
    private String[] availableCourses;
    private int strength;
    // Generates Getters and Setters...

    public School() {}
}