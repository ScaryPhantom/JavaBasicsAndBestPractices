INSERT INTO PRODUCT (id, name, price,description) VALUES (1, 'iPod', 99.99,'a portable media player');
INSERT INTO PRODUCT (id, name, price,description) VALUES (2, 'iPad', 699.99,'a tablet computer');
INSERT INTO PRODUCT (id, name, price,description) VALUES (3, 'macBook', 999.99,'a notebook computer');