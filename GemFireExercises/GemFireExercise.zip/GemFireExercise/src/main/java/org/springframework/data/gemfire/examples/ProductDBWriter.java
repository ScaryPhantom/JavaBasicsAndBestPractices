package org.springframework.data.gemfire.examples;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.gemfire.examples.Product;
import org.springframework.data.gemfire.examples.ProductRepository;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.geode.cache.CacheWriter;
import org.apache.geode.cache.CacheWriterException;
import org.apache.geode.cache.EntryEvent;
import org.apache.geode.cache.RegionEvent;

@Component
public class ProductDBWriter implements CacheWriter<Long, Product> {

	@Autowired
	private ProductRepository productRepository;

	private static Log log = LogFactory.getLog(ProductDBWriter.class);
	/* (non-Javadoc)
	 * @see org.apache.geode.cache.CacheCallback#close()
	 */
	@Override
	public void close() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see org.apache.geode.cache.CacheWriter#beforeCreate(org.apache.geode.cache.EntryEvent)
	 */
	@Override
	@Async
	public void beforeCreate(EntryEvent<Long, Product> entryEvent) throws CacheWriterException {
		if (productRepository.findById(Long.parseLong(String.valueOf(entryEvent.getKey()))).isPresent()) {
			update(entryEvent.getNewValue());
		}
	}

	/* (non-Javadoc)
	 * @see org.apache.geode.cache.CacheWriter#beforeDestroy(org.apache.geode.cache.EntryEvent)
	 */
	@Override
	@Async
	public void beforeDestroy(EntryEvent<Long, Product> entryEvent) throws CacheWriterException {
		delete(Long.parseLong(String.valueOf(entryEvent.getKey())));
	}

	/* (non-Javadoc)
	 * @see org.apache.geode.cache.CacheWriter#beforeRegionClear(org.apache.geode.cache.RegionEvent)
	 */
	@Override
	public void beforeRegionClear(RegionEvent<Long, Product> entryEvent) throws CacheWriterException {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see org.apache.geode.cache.CacheWriter#beforeRegionDestroy(org.apache.geode.cache.RegionEvent)
	 */
	@Override
	public void beforeRegionDestroy(RegionEvent<Long, Product> regionEvent)
			throws CacheWriterException {
		// TODO Auto-generated method stub
	}

	/* (non-Javadoc)
	 * @see org.apache.geode.cache.CacheWriter#beforeUpdate(org.apache.geode.cache.EntryEvent)
	 */
	@Override
	@Async
	public void beforeUpdate(EntryEvent<Long, Product> entryEvent) throws CacheWriterException {
		update(entryEvent.getNewValue());
	}

	private void update(Product product) {
		log.debug("updating the database");
		productRepository.save(product);
	}

	private void delete(Long id) {
		log.debug("deleting id " + id + " from the database");
		productRepository.deleteById(id);
	}
}