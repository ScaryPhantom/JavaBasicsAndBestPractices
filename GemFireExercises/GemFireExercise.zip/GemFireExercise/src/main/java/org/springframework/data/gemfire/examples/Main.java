package org.springframework.data.gemfire.examples;

import java.math.BigDecimal;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.gemfire.examples.Product;
import org.springframework.data.gemfire.examples.ProductRepository;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.geode.cache.Region;

@SpringBootApplication
public class Main {

	private static Log log = LogFactory.getLog(Main.class);

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws InterruptedException {

		if (args.length >= 1) {
			log.debug("Setting the spring profile to " + args[0]);
			System.setProperty("spring.profiles.active", args[0]);
		}

		ApplicationContext context = new ClassPathXmlApplicationContext(
				"app-context.xml");

		Region<Long,Product> region = context.getBean(Region.class);
		ProductRepository productRepository = context.getBean(ProductRepository.class);

		for (long i = 1; i<=3; i++){
			Product p = region.get(i);
			log.debug("Retrieved product " + p.getName() + " from cache");
		}

		 //Let's try this again

		log.debug("2nd pass...This time the CacheLoader is not called since items are already cached");
		for (long i = 1; i<=3; i++){
			Product p = region.get(i);
			log.debug("Retrieved product " + p.getName() + " from cache");
		}

		//Create a new product
		log.debug("Adding a new product to the cache...");

		Product iphone = new Product(4L, "Apple IPhone", new BigDecimal(299.99),"Smart phone");
		region.put(iphone.getId(), iphone);

		while (productRepository.count() == 3) {
			log.debug("Product repository still has : " + productRepository.count() + " rows");
			Thread.sleep(10);
		}
		log.debug("Product repository now has : " + productRepository.count() + " rows");

		log.debug("Removing a product from the cache...");
		region.destroy(4L);

		while (productRepository.count() == 4) {
			log.debug("Product repository still has : " + productRepository.count() + " rows");
			Thread.sleep(10);
		}
		log.debug("Product repository now has : " + productRepository.count() + " rows");
	}
}