package org.springframework.data.gemfire.examples;

import org.springframework.data.gemfire.examples.Product;
import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<Product,Long> {

}