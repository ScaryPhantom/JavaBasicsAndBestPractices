package org.springframework.data.gemfire.examples;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.gemfire.examples.Product;
import org.springframework.data.gemfire.examples.ProductRepository;
import org.springframework.stereotype.Component;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.geode.cache.CacheLoader;
import org.apache.geode.cache.CacheLoaderException;
import org.apache.geode.cache.LoaderHelper;

@Component
public class ProductDBLoader implements CacheLoader<Long, Product> {

	@Autowired
	private ProductRepository productRepository;

	private static Log log = LogFactory.getLog(ProductDBLoader.class);

	/* (non-Javadoc)
	 * @see org.apache.geode.cache.CacheCallback#close()
	 */
	@Override
	public void close() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see org.apache.geode.cache.CacheLoader#load(org.apache.geode.cache.LoaderHelper)
	 */
	@Override
	public Product load(LoaderHelper<Long, Product> loadHelper) throws CacheLoaderException {
		Long id = Long.parseLong(String.valueOf(loadHelper.getKey()));
		log.debug("loading product id " + id + " from the database");
		return productRepository.findById(id).orElse(null);
	}
}