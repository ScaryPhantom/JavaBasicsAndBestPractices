
public class Main {

	public static void main(String[] args) {

	ListOfNumbers2 list2 = new ListOfNumbers2();
	list2.writeList();
	
	}

}
