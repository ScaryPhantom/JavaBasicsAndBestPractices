
public class Main {

	public static void main(String[] args) {

	ListOfNumbers list = new ListOfNumbers();
	list.writeList();	

	
	}

}
