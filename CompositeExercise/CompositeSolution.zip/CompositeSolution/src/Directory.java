import java.util.ArrayList;
import java.util.List;

class Directory implements File {
	private long value1;
	private List<File> files = new ArrayList<>();

	public Directory(long l) {
		this.value1=l;
	}

	public String getType() {

		return "directory";

	}

	public void addFile(File file) {

		files.add(file);

	}

	public Long getSize() {

		Long size = 0L;

		for (File file : files) {

			size = size + file.getSize();

		}

		return size;

	}

}