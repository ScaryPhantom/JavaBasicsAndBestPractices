interface File {
    public String getType();
    public Long getSize();
}