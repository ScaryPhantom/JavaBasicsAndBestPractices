public interface State {
  public void pressPlay(MP3PlayerContext context);
}