import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		PlayingState playing = new PlayingState();
		StandbyState standby = new StandbyState();
		String opcion = "1";
		MP3PlayerContext reproductor = new MP3PlayerContext(playing);

		while (!opcion.equals("0")) {

			Scanner op = new Scanner(System.in);
			System.out.println("Selecciona una opcion");
			System.out.println("Opcion 1 reproducir");
			System.out.println("Opcion 2 stand by");

			opcion = op.nextLine();
			switch (opcion) {

			case "1":
				standby.pressPlay(reproductor);
				System.out.println(reproductor.getState());
				break;
			case "2":
				playing.pressPlay(reproductor);
				System.out.println(reproductor.getState());
				break;
			case "0":
				break;

			}
		}
	}
}
