
public class PrototypeMain {
	public static void main(String[] args) throws Exception {
		ApparelStore appstore = new ApparelStore();
		appstore.setStorename("Prototype Store");
		appstore.fetchData();
		System.out.println(appstore);
		ApparelStore duplicatedappstore = appstore.clone();
		duplicatedappstore.setStorename("Cloned Store");
		System.out.println(duplicatedappstore);
	}
}
