
public class Cup implements Utensil {

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double getPrice() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double getSize() {
		// TODO Auto-generated method stub
		return null;
	}

}
