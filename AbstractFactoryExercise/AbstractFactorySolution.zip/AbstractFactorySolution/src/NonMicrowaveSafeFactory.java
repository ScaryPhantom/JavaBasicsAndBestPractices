
public class NonMicrowaveSafeFactory implements AbstractUtensilFactory{
	public Utensil getPlate() {

		return new Plate_MW();

		}

		public Utensil getBowl() {

		return new Bowl_MW();

		}

		public Utensil getCup() {

		return new Cup_MW();

		}
}
