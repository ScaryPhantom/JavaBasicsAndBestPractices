
public class Application {

	public static void main(String[] args) {
		AbstractUtensilFactory utensilFactory = FactoryProducer.getFactory("Microwave");
		Utensil utensil = utensilFactory.getPlate();
		utensil.getPrice();
	}

}
