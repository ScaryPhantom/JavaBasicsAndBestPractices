
public interface AbstractUtensilFactory {
	public Utensil getPlate();
	public Utensil getBowl();
	public Utensil getCup();
}
