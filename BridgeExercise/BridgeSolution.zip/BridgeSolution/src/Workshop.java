// Implementor for bridge pattern
interface Workshop
{
    abstract public void work();
}
 
