public enum BrushSize {
  THIN, MEDIUM, THICK
}