
public class Main {

	public static void main(String[] args) {

		Person person1 = new Person("Javier", "Aguilar", 30);
		System.out.println(person1.getFirstName());
		System.out.println(person1.getLastName());
		System.out.println(person1.getAge());
		System.out.println(person1.getAddress());
		System.out.println(person1.getPhone());

	}

}
