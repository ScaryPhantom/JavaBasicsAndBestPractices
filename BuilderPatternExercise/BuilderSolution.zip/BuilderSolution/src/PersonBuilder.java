
public class PersonBuilder 
    {
        final String firstName;
        final String lastName;
        int age;
        String phone;
        String address;
 
        public PersonBuilder(String firstName, String lastName) 
        {
            this.firstName = firstName;
            this.lastName = lastName;
        }
        public PersonBuilder age(int age) 
        {
            this.age = age;
            return this;
        }
        public PersonBuilder phone(String phone) 
        {
            this.phone = phone;
            return this;
        }
        public PersonBuilder address(String address) 
        {
            this.address = address;
            return this;
        }
        
        //Return the finally constructed Person object
        public Person build() 
        {
            return new Person(this);
        }
        
    }
