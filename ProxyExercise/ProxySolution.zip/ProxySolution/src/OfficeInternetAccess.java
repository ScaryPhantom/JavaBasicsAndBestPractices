
public interface OfficeInternetAccess {
	
	public void grantInternetAccess();

}
