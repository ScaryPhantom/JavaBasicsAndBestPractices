package com.example.ExampleMongoDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleMongoDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
