package com.example.mdbspringboot;

public interface CustomItemRepository {
	void updateItemQuantity(String name, float newQuantity);
}
