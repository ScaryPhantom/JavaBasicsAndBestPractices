// The roots of the equation
class Roots {
  public double x1;
  public double x2;
}

// Class that solves the quadratic equation - this class will be tested by another class.
// a*x^2 + b*x + c = 0
public class SquareEquation {

  // The coefficients of the equation
  private double a, b, c;

  // Constructor
  public SquareEquation(double a, double b, double c) {
    this.a = a; this.b = b; this.c = c;
  }

  // The method of solving the quadratic equation
  public Roots Solution() {
    // Discriminant
    double d = b*b - 4*a*c;

    // Checking if the equation has roots
    if (d<0)
      throw new ArithmeticException("Solution has no roots.");

    // Calculate the result
    Roots result = new Roots();
    result.x1 = (-b - Math.sqrt(d)) / (2*a);
    result.x2 = (-b + Math.sqrt(d)) / (2*a);

    // Return the result
    return result;
  }
}