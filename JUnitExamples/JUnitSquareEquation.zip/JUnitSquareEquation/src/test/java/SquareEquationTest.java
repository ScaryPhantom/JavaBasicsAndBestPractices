import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SquareEquationTest {

	private SquareEquation se;

	@BeforeEach
	void setUp() throws Exception {
		// This method is called first.
		// Create an instance of the SquareEquation class.
		se = new SquareEquation(2, 1, -3); // 2*x^2 + x - 3 = 0
	}

	@Test
	void testSolution() {
		// Declare an instance of the Roots class
		Roots rt = se.Solution();

		// Solution check x1
		assertEquals(rt.x1, -1.5);

		// Solution check x2
		assertEquals(rt.x2, 1.0);
		
		// Making it fail
		assertEquals(rt.x2, 777.777);

	}
}
