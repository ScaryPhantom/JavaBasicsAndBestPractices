package com.example.ExceptionHandlingExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExceptionHandlingExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExceptionHandlingExampleApplication.class, args);
	}

}
