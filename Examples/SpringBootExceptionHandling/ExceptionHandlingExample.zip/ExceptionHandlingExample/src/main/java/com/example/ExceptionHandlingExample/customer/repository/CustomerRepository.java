package com.example.ExceptionHandlingExample.customer.repository;

//Step 2: Creating a Repository
//Interface extending
//JpaRepository

import com.example.ExceptionHandlingExample.customer.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository
	extends JpaRepository<Customer, Long> {
}
