package com.example.ExceptionHandlingExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceptionHandlingExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
